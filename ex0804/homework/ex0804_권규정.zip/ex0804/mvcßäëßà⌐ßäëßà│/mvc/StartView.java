package ex0804.homework.ex0804.mvc소스.mvc;

class StartView {
	public static void main(String[] args) {
		System.out.println("-----------프로그램 시작합니다. -----------------");

		new MenuView().printMenu();
	}
}

package ex0804.homework.ex0804.lotto;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/*
    1. ArrayList를 이용하여 로또번호 6개를 중복없이 저장하고 올림차순으로 정렬해서 출력한다.
 */

public class Lotto {
    public static void main(String[] args) {
        int number = 0;
        List<Integer> list = new ArrayList<>(6);
        for (int i = 0; i < 6; i++) {
            number = (int) ((Math.random() * 45) + 1);
            if (!list.contains(number)) {
                list.add(number);
            } else {
                i--;
            }
        }
        Collections.sort(list);
        System.out.println(list);
    }
}

package ex0802.homework.ch8.exam3;

public interface Soundable {
    String sound();
}

package ex0802.homework.ch8.exam3;

public class Dog implements Soundable{
    @Override
    public String sound() {
        return "멍멍";
    }
}

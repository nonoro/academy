package ex0802.homework.ch8.exam3;

public class Cat implements Soundable {

    @Override
    public String sound() {
        return "야옹";
    }
}

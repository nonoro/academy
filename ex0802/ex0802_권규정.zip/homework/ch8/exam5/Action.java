package ex0802.homework.ch8.exam5;

public interface Action {
    void work();
}

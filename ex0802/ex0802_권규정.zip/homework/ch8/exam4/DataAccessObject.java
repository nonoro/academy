package ex0802.homework.ch8.exam4;

public interface DataAccessObject {
    void select();

    void insert();

    void update();

    void delete();
}

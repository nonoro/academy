package ex0802.homework.interfaceStudy_실습;

public interface ElecFunction {
    void start();

    void stop();

    void display();
}

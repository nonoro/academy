package util;

public interface DbProperties {
    String DRIVER_NAME = "oracle.jdbc.driver.OracleDriver";
    String URL = "jdbc:oracle:thin:@localhost:1521:xe";
    String USER_ID = "EX0819_HOMEWORK";
    String USER_PWD = "1234";
}

package ex0811.homework.profile;

import ex0811.homework.MenuExam;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

public class Profile extends JFrame { // BoarderLayoutManager 기본으로 가지고 있다.
    JButton btn1 = new JButton("1. 프로필저장");
    JButton btn2 = new JButton("2. 프로필 불러오기");
    JButton btn3 = new JButton("3. 종료");


    /**
     * 주로 화면구성을 생성자에서 작성한다.
     */
    public Profile() {
        super("프로필");

        //JFrame의 LayoutManager를 변경하자
        setLayout(new FlowLayout(FlowLayout.LEFT, 30, 40));

        //JButton추가하기
//        add(btn1, BorderLayout.EAST);
//        add(btn2, BorderLayout.SOUTH);
        add(btn1);
        add(btn2);
        add(btn3);
        btn1.setPreferredSize(new Dimension(300, 40));
        btn2.setPreferredSize(new Dimension(300, 40));
        btn3.setPreferredSize(new Dimension(300, 40));

        Font font = new Font("궁서 보통", Font.ITALIC, 30);
        btn1.setFont(font);
        btn2.setFont(font);
        btn3.setFont(font);


        //창의 크기
        setSize(1000, 500);

        //창의 위치 설정
//        setLocation(300, 200);
        setLocationRelativeTo(null); //정중앙에 놓기 (먼저 창의 크기가 정해져야함)


        //화면보여줘
        super.setVisible(true);

        //x를 클릭하면 프로그램 종료

        setDefaultCloseOperation(Profile.EXIT_ON_CLOSE);

        btn3.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0); //프로그램 종료
            }
        });

        btn1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = JOptionPane.showInputDialog("이름을 입력하세요");
                String weight = JOptionPane.showInputDialog("몸무게를 입력하세요");
                String passWord = JOptionPane.showInputDialog("비밀번호를 입력하세요");

                File file = new File("ex0811/homework/profile/" + name + ".txt");

                try (BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(file))) {
                    String str = ";";
                    bufferedOutputStream.write(weight.getBytes());
                    bufferedOutputStream.write(str.getBytes());
                    bufferedOutputStream.write(passWord.getBytes());

                } catch (Exception exception) {
                    exception.printStackTrace();
                }

            }
        });

        btn2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String name = JOptionPane.showInputDialog("이름을 입력하세요");

                File file = new File("ex0811/homework/profile/" + name + ".txt");

                try (BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(file))) {
                    byte[] bytes = bufferedInputStream.readAllBytes();
                    String str = new String(bytes);
                    String[] split = str.split(";");
                    JOptionPane.showMessageDialog(null, name + "님의 몸무게는" + split[0] + "kg이고 비번은 " + split[1] + " 입니다.", name + "님의 profile", JOptionPane.INFORMATION_MESSAGE);

                } catch (Exception exception) {
                    exception.printStackTrace();
                }

            }
        });



    }

    public static void main(String[] args) {
        new Profile();
    }
}

package ex0805.homework.MVC_Collection.boardClass.model.util;

public class DuplicateException extends Exception {
    public DuplicateException() {

    }

    public DuplicateException(String message) {
        super(message);
    }
}

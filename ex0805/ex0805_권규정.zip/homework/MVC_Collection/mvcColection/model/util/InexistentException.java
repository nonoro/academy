package ex0805.homework.MVC_Collection.mvcColection.model.util;

public class InexistentException extends Exception {
    public InexistentException() {

    }

    public InexistentException(String message) {
        super(message);
    }
}

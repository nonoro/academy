package ex0725.과제._5장_확인문제;

public class Excercise6 {
    public static void main(String[] args) {
    // 6번 답 : array.length -> 3 , array[2].length -> 5
        int[][] array = {
                {95, 86},
                {83, 92, 96},
                {78, 83, 93, 87, 88}
        };
        System.out.println(array.length);
        System.out.println(array[2].length);
    }
}





/*
  본인이름: 권규정
  날짜: 22.07.25
  주제 : 확인문제 6번
*/
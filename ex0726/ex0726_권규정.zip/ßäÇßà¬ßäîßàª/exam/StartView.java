package ex0726.exam;

/*
    시작
 */

import ex0726.exam.view.MenuView;

public class StartView {
    public static void main(String[] args) {
        new MenuView().printMenu();
    }
}


/*
  본인이름: 권규정
  날짜: 22.07.26
  주제 : 상품과제
*/
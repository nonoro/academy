package ex0729.과제._6장확인문제;



public class Printer {

    //  Exam16
//    public void print(int i) {
//        System.out.println(i);
//    }
//
//    public void print(boolean b) {
//        System.out.println(b);
//    }
//
//    public void print(double d) {
//        System.out.println(d);
//    }
//
//    public void print(String s) {
//        System.out.println(s);
//    }

    // Exam17
    public static void print(int i) {
        System.out.println(i);
    }

    public static void print(boolean b) {
        System.out.println(b);
    }

    public static void print(double d) {
        System.out.println(d);
    }

    public static void print(String s) {
        System.out.println(s);
    }
}


/*
  본인이름: 권규정
  날짜: 22.07.29
  주제 : 확인문제16, 17
*/

package ex0729.과제._6장확인문제;



public class Member {
    //  Exam13
    String name;
    String id;
    String password;
    int age;

    //  Exam14
    Member(String name, String id) {
        this.name = name;
        this.id = id;
    }

}

/*
  본인이름: 권규정
  날짜: 22.07.29
  주제 : 확인문제13, 14
*/
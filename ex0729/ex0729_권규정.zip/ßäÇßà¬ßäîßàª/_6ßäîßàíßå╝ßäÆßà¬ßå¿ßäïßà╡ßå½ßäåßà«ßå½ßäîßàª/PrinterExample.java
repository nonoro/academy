package ex0729.과제._6장확인문제;

public class PrinterExample {
    public static void main(String[] args) {
        // Exam16
//        Printer printer = new Printer();
//        printer.print(10);
//        printer.print(true);
//        printer.print(5.7);
//        printer.print("홍길동");

        // Exam17
        Printer.print(10);
        Printer.print(true);
        Printer.print(5.7);
        Printer.print("홍길동");
    }
}


/*
  본인이름: 권규정
  날짜: 22.07.29
  주제 : 확인문제16, 17
*/

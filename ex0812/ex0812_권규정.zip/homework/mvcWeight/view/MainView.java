package ex0812.homework.mvcWeight.view;


public class MainView {
    public static void showMenu() {
        System.out.println("다음 사항에 맞게 입력하여 주십시요");
        System.out.println("\t\t\t\t몸무게 입력은 1 번");
        System.out.println("\t\t\t\t몸무게 검색은 2 번");
        System.out.println("\t\t\t\t몸무게 변경은 3 번");
        System.out.println("\t\t\t\t비밀번호변경은 4 번");
        System.out.println("\t\t\t\t비밀번호찾기는 5 번");
        System.out.println("\t\t\t\t프로그램 종료는 6 번");
        System.out.println("을 입력후 Enter 을 눌러 주십시요");
        System.out.print("메뉴 선택 : ");

    }
}




package ex0812.homework.mvcWeight;

import ex0812.homework.mvcWeight.controller.WeightController;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        new WeightController().run();
    }
}


1) Service의 insert, update 리턴타입 void로 수정한다.

2) ElectronicsArrayBoundsException 만든다.
     : Electroincs 배열의 길이를 벗어났을대...


3) SearchNotFoundException만든다.
    : 검색 결과가 null 일때
    


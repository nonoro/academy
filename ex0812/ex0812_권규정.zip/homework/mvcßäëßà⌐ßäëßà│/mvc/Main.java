package ex0812.homework.mvc소스.mvc;

import ex0812.homework.mvc소스.mvc.controller.ElectronicsController;

class Main {
	public static void main(String[] args) {
		new ElectronicsController().run();
	}
}

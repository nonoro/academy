package ex0812.homework.mvc소스.mvc.view;

/**
 * 사용자의 요청을 키보드로 입력받는 클래스
 */
public class MenuView {

    /**
     * 전체 메뉴를 출력하는 메소드
     */
    public static void printMenu() {
            System.out.println("-----------------------------------------------------------------------------------------");
            System.out.println("1. 전체검색    2. 모델번호검색     3.등록     4. 수정     5. 삭제     9. 종료");
            System.out.println("-----------------------------------------------------------------------------------------");
            System.out.print("메뉴선택 > ");

        }
    }




package ex0803.homework._7;

public class NotExistIDException extends Exception {
    public NotExistIDException() {
    }
    public NotExistIDException(String message) {
        super(message);
    }
}

public class  StartView{
	public static void main(String[] args) {
		
	}
}
